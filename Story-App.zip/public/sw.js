const CACHE_NAME = 'story-app-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/styles/styles.css',
  '/styles/transitions.css',
  '/app.js',
  '/main.js',
  '/public/favicon.png',
  '/public/logo-192.png',
  '/public/logo-512.png',
];

// Install event
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return Promise.all(
        STATIC_ASSETS.map(async (url) => {
          try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`Failed to fetch: ${url}`);
            await cache.put(url, response.clone());
          } catch (err) {
            console.warn(`❌ Failed to cache ${url}:`, err.message);
          }
        })
      );
    })
  );
  self.skipWaiting();
});

// Activate event
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// Fetch event
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request).catch(() => {
        return new Response('<h1>Offline</h1>', {
          headers: { 'Content-Type': 'text/html' }
        });
      });
    })
  );
});

// Push Notification event
self.addEventListener('push', function (event) {
  let data = {
    title: 'Story Notification',
    body: 'Anda menerima notifikasi baru.',
    icon: '/public/logo-192.png',
  };

  try {
    if (event.data) {
      const payload = event.data.json();
      data.title = payload.title || data.title;
      data.body = payload.options?.body || data.body;
      data.image = payload.options?.image || data.image;
    }
  } catch (err) {
    console.warn('❌ Push event data parsing failed:', err.message);
  }

  const options = {
    body: data.body,
    icon: data.icon,
    image: data.image,
    vibrate: [100, 50, 100],
    data: {
      url: '/',
    },
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Notification click event
self.addEventListener('notificationclick', function (event) {
  event.notification.close();

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windowClients => {
      for (const client of windowClients) {
        if (client.url === event.notification.data.url && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(event.notification.data.url);
      }
    })
  );
});
