import Router from './routes/routes.js';

class App {
  constructor() {
    this.previousPath = '';

    this.init();
    this.registerServiceWorker();
  }

  async init() {
    window.addEventListener('hashchange', () => {
      this._renderPage();
    });

    window.addEventListener('load', () => {
      this._renderPage();
    });
  }

  async _renderPage() {
    if (!document.startViewTransition) {
      await Router.render();
      return;
    }

    const currentPath = window.location.hash;
    const previousPath = this.previousPath || '';
    this.previousPath = currentPath || '';

    console.log('Transisi :', { from: previousPath, to: currentPath });

    let transitionClass = null;

    if (previousPath.includes('/login') && currentPath.includes('/register')) {
      transitionClass = 'login-to-register';
    } else if (previousPath.includes('/register') && currentPath.includes('/login')) {
      transitionClass = 'register-to-login';
    } else if (previousPath.includes('/login') && currentPath.includes('/')) {
      transitionClass = 'login-to-home';
    } else if (previousPath.includes('/') && currentPath.includes('/login')) {
      transitionClass = 'home-to-login';
    } else if (previousPath.includes('/') && currentPath.startsWith('/story-detail/story')) {
      transitionClass = 'home-to-detail';
    } else if (previousPath.includes('/story-detail/:id') && currentPath.includes('/')) {
      transitionClass = 'detail-to-home';
    } else if (previousPath.includes('/') && currentPath.includes('/add-story')) {
      transitionClass = 'home-to-add';
    } else if (previousPath.includes('/add-story') && currentPath.includes('/')) {
      transitionClass = 'add-to-home';
    }

    if (transitionClass) {
      document.documentElement.classList.add(transitionClass);
    }

    const transition = document.startViewTransition(async () => {
      await Router.render();
    });

    try {
      await transition.finished;
    } catch (error) {
      console.error('View Transition gagal:', error);
    } finally {
      document.documentElement.classList.remove(transitionClass);
    }
  }

  registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then(reg => console.log('✅ Service Worker registered:', reg.scope))
          .catch(err => console.error('❌ Service Worker registration failed:', err));
      });
    }
  }
}

const appInstance = new App();
export default appInstance;
