import L from 'leaflet';

class Map {
  #map = null;
  #zoom = 13;

  static async build(selector, options = {}) {
    const map = new Map(selector, options);
    
    if (options.locate) {
      try {
        const position = await Map.getCurrentPosition();
        const center = [position.coords.latitude, position.coords.longitude];
        map.changeCamera(center);
      } catch (error) {
        console.error('Error getting location:', error);
      }
    }

    return map;
  }

  static getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (!('geolocation' in navigator)) {
        reject(new Error('Geolocation not supported'));
        return;
      }

      navigator.geolocation.getCurrentPosition(resolve, reject);
    });
  }

  constructor(selector, options = {}) {
    const element = document.querySelector(selector);
    if (!element) {
      throw new Error(`Element ${selector} not found`);
    }

    this.#map = L.map(element, {
      zoom: options.zoom || this.#zoom,
      center: options.center || [-6.2, 106.816666],
      scrollWheelZoom: true,
      zoomControl: true
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
      className: 'map-tiles'
    }).addTo(this.#map);
  }

  changeCamera(coordinate, zoom = null) {
    this.#map.setView(coordinate, zoom || this.#zoom);
  }

  getCenter() {
    const center = this.#map.getCenter();
    return {
      latitude: center.lat,
      longitude: center.lng
    };
  }

  addMarker(coordinate, options = {}) {
    const marker = L.marker(coordinate, {
      ...options,
      draggable: options.draggable || false
    });
    
    marker.addTo(this.#map);
    
    if (options.popup) {
      marker.bindPopup(options.popup);
    }
    
    return marker;
  }

  addMapEventListener(event, callback) {
    this.#map.on(event, callback);
  }
}

export default Map;
