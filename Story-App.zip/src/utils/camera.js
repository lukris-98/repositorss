export default class Camera {
  #currentStream;
  #streaming = false;
  #width = 640;
  #height = 0;

  #videoElement;
  #selectCameraElement;
  #canvasElement;
  #takePictureButton;

  static addNewStream(stream) {
    if (!Array.isArray(window.currentStreams)) {
      window.currentStreams = [stream];
    } else {
      window.currentStreams.push(stream);
    }
  }

  static stopAllStreams() {
    if (!Array.isArray(window.currentStreams)) {
      return;
    }
    window.currentStreams.forEach((stream) => {
      stream?.getTracks()?.forEach((track) => track.stop());
    });
    window.currentStreams = [];
  }

  constructor({ video, cameraSelect, canvas, options = {} }) {
    this.#videoElement = video;
    this.#selectCameraElement = cameraSelect;
    this.#canvasElement = canvas;

    this.#initialListener();
  }

  #initialListener() {
    this.#videoElement.oncanplay = () => {
      if (this.#streaming) return;

      this.#height = (this.#videoElement.videoHeight * this.#width) / this.#videoElement.videoWidth;
      this.#canvasElement.width = this.#width;
      this.#canvasElement.height = this.#height;
      this.#streaming = true;
    };

    this.#selectCameraElement.onchange = async () => {
      await this.stop();
      await this.launch();
    };
  }

  async #populateDeviceList(stream) {
    try {
      if (!(stream instanceof MediaStream)) {
        throw new Error('MediaStream not found!');
      }

      const { deviceId } = stream.getVideoTracks()[0]?.getSettings();
      const devices = await navigator.mediaDevices.enumerateDevices();
      const cameras = devices.filter((d) => d.kind === 'videoinput');

      this.#selectCameraElement.innerHTML = cameras.map((device, index) => `
        <option value="${device.deviceId}" ${deviceId === device.deviceId ? 'selected' : ''}>
          ${device.label || `Camera ${index + 1}`}
        </option>`).join('');
    } catch (error) {
      console.error('#populateDeviceList error:', error);
    }
  }

  async #getStream() {
    try {
      const deviceId = this.#selectCameraElement.value || undefined;

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          aspectRatio: 4 / 3,
          deviceId: deviceId ? { exact: deviceId } : undefined,
        },
      });

      await this.#populateDeviceList(stream);
      return stream;
    } catch (error) {
      console.error('#getStream error:', error);
      return null;
    }
  }

  async launch() {
    this.#currentStream = await this.#getStream();
    if (!this.#currentStream) return;

    Camera.addNewStream(this.#currentStream);
    this.#videoElement.srcObject = this.#currentStream;
    try {
      await this.#videoElement.play();
    } catch (err) {
      console.warn('Video play() failed:', err);
    }

    this.#clearCanvas();
  }

  async stop() {
    if (this.#videoElement) {
      this.#videoElement.pause();
      this.#videoElement.srcObject = null;
    }

    if (this.#currentStream instanceof MediaStream) {
      this.#currentStream.getTracks().forEach((track) => track.stop());
      this.#currentStream = null;
    }

    this.#streaming = false;
    this.#clearCanvas();
  }

  #clearCanvas() {
    const ctx = this.#canvasElement.getContext('2d');
    ctx.fillStyle = '#AAAAAA';
    ctx.fillRect(0, 0, this.#canvasElement.width, this.#canvasElement.height);
  }

  async takePicture() {
    if (!(this.#width && this.#height)) return null;

    const ctx = this.#canvasElement.getContext('2d');
    this.#canvasElement.width = this.#width;
    this.#canvasElement.height = this.#height;
    ctx.drawImage(this.#videoElement, 0, 0, this.#width, this.#height);

    return await new Promise((resolve) => {
      this.#canvasElement.toBlob((blob) => resolve(blob));
    });
  }

  addTakePictureListener(selector, callback) {
    this.#takePictureButton = document.querySelector(selector);
    if (this.#takePictureButton) {
      this.#takePictureButton.onclick = callback;
    }
  }
}
