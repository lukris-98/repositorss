import UrlParser from './url-parser.js';
import LoginPage from '../pages/auth/login-page.js';
import RegisterPage from '../pages/auth/register-page.js';
import HomePage from '../pages/home/home-page.js';
import AddStoryPage from '../pages/add-story/add-story-page.js';
import StoryDetailPage from '../pages/story-detail/story-detail-page.js';

const routes = {
  '/': HomePage,
  '/login': LoginPage,
  '/register': RegisterPage,
  '/add-story': AddStoryPage,
  '/story-detail/:id': StoryDetailPage,
};

const Router = {
  async render() {
    const url = location.hash.slice(1).toLowerCase() || '/';
    let page = null;

    if (routes[url]) {
      page = routes[url];
    } else {
      for (const route in routes) {
        const routeParts = route.split('/');
        const urlParts = url.split('/');

        if (routeParts.length === urlParts.length) {
          let match = true;
          for (let i = 0; i < routeParts.length; i++) {
            if (routeParts[i].startsWith(':')) continue;
            if (routeParts[i] !== urlParts[i]) {
              match = false;
              break;
            }
          }
          if (match) {
            page = routes[route];
            break;
          }
        }
      }
    }

    if (!page) page = HomePage;

    const content = document.getElementById('content');
    content.innerHTML = await page.render();
    await page.afterRender();
  },
};

export default Router;
