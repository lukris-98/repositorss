const UrlParser = {
  parseActiveUrlWithCombiner() {
    const url = this._parseUrl();
    const combined = (url.resource ? '/' + url.resource : '/') +
      (url.id ? '/:id' : '') +
      (url.verb ? '/' + url.verb : '');
    return combined;
  },

  _parseUrl() {
    const url = location.hash.slice(1) || '/';
    const r = url.split('/');
    const request = {
      resource: null,
      id: null,
      verb: null,
    };
    request.resource = r[1] || null;
    request.id = r[2] || null;
    request.verb = r[3] || null;
    return request;
  },
};

export default UrlParser;
