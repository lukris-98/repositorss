import StoryDetailPagePresenter from './story-detail-page-presenter.js';
import Map from '../../utils/map.js';

const StoryDetailPage = {
  async render() {
    return `
      <div data-page="detail">
        <div class="container mx-auto max-w-4xl p-4">
          <header>
            <h1>Story Detail</h1>
            <a href="#/" class="kembali">
              KEMBALI
            </a>
          </header>
          <div id="story-detail">
            <p>Loading Story...</p>
          </div>
          <div id="map" style="height: 400px; margin-top: 1rem; display: none;"></div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    this.storyDetailContainer = document.getElementById('story-detail');
    this.mapContainer = document.getElementById('map');
    this.presenter = new StoryDetailPagePresenter(this);
    this.presenter.init();
  },

  showStory(story) {
    this.storyDetailContainer.innerHTML = `
      <article>
        <h2>${story.name}</h2>
        <img 
        src="${story.photoUrl}" 
        alt="Photo : ${story.id}" 
        style="width: 100%; max-height: 600px; object-fit: contain; margin: 1rem 0; border-radius: 8px;" 
        view-transition-name="story-image" />
        
        <p><strong>Deskripsi:</strong> ${story.description}</p>
        <div class="story-detail-info">
          <p>Dibuat: ${new Date(story.createdAt).toLocaleString()}</p>
          ${story.lat && story.lon ? `<p>Posisi: Lat (${story.lat}), Lon (${story.lon})</p>` : ''}
        </div>
      </article>
    `;
  },

  async showMap(story) {
    if (!story.lat || !story.lon) return;

    this.mapContainer.style.display = 'block';

    try {
      const map = await Map.build('#map', {
        center: [story.lat, story.lon],
        zoom: 13,
      });

      const address = await this._getAddressFromCoordinates(story.lat, story.lon);
      const popupContent = address || 'Lokasi tidak ditemukan';

      map.addMarker([story.lat, story.lon], {
        popup: popupContent
      });
    } catch (error) {
      console.error('Gagal Merender Map:', error);
    }
  },

  async _getAddressFromCoordinates(lat, lon) {
    const apiKey = '5f39fa7f10e74d8983ca65bc4552f561'; 
    const url = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lon}&key=${apiKey}&language=id`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (data.results && data.results.length > 0) {
        return data.results[0].formatted;
      }

      return null;
    } catch (error) {
      console.error('API OpenCage error:', error);
      return null;
    }
  },

  showError(message) {
    this.storyDetailContainer.innerHTML = `<p role="alert">${message}</p>`;
    if (this.mapContainer) {
      this.mapContainer.style.display = 'none';
    }
  }
};

export default StoryDetailPage;
