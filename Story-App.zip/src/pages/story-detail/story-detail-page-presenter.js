import Api from '../../data/api.js';
import UrlParser from '../../routes/url-parser.js';

class StoryDetailPagePresenter {
  constructor(view) {
    this.view = view;
  }

  async init() {
    const url = UrlParser._parseUrl();
    const id = url.id;

    if (!id) {
      this.view.showError('Maaf ID Story Tidak Ditemukan');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      this.view.showError('Kamu Harus Login Dulu Geis..');
      return;
    }

    try {
      const response = await Api.getStoryDetail({ token, id });
      console.log('getStoryDetail response:', response);

      if (!response.error) {
        this.view.showStory(response.story);

        if (response.story.lat && response.story.lon) {
          this.view.showMap(response.story);
        }
      } else {
        this.view.showError(response.message || 'Gagal Memuat story.');
      }
    } catch (error) {
      console.error('Eror Untuk Memuat Detail Story:', error);
      this.view.showError('Gagal, Coba Lagi Dong..');
    }
  }
}

export default StoryDetailPagePresenter;
