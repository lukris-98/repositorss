import RegisterPagePresenter from './register-page-presenter.js';

const RegisterPage = {
  async render() {
    return `
      <div id="auth" data-page="register">
        <div class="register-container">
          <div class="register-card">
            <header>
              <h1>Register</h1>
            </header>
            <form id="register-form">
              <label for="name">Nama</label>
              <input type="text" id="name" name="name" required placeholder="Masukkan Namamu" />
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required placeholder="you@example.com" />
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required minlength="8" placeholder="Minimal 8 Karakter" />
              <button type="submit" id="submit-button">Daftar</button>
            </form>
            <p>Sudah Punya Akun ? <a href="#/login">Masuk</a></p>
            <div id="register-message" role="alert" aria-live="polite"></div>
          </div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    const formElement = document.getElementById('register-form');
    const messageElement = document.getElementById('register-message');
    const submitButton = document.getElementById('submit-button');

    const presenter = new RegisterPagePresenter({
      onSuccess: () => {
        formElement.reset();
        window.location.hash = '#/login';
      },
      onMessage: (message) => {
        messageElement.textContent = message;
      },
      onLoading: (isLoading) => {
        submitButton.disabled = isLoading;
        submitButton.textContent = isLoading ? 'Loading...' : 'Daftar';
      },
    });

    formElement.addEventListener('submit', (event) => {
      event.preventDefault();

      const name = formElement.name.value.trim();
      const email = formElement.email.value.trim();
      const password = formElement.password.value.trim();

      presenter.submitRegistration({ name, email, password });
    });
  },
};

export default RegisterPage;
