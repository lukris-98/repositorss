import LoginPagePresenter from './login-page-presenter.js';

class LoginPage {
  async render() {
    return `
      <div id="auth" data-page="login">
        <div class="login-container">
          <div class="login-card">
            <header class="header-login">
              <h1>Login</h1>
            </header>
            <form id="login-form">
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required placeholder="you@example.com" />
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required minlength="8" placeholder="Your password" />
              <button type="submit" id="submit-button">Masuk</button>
            </form>
            <p>Belum punya akun ? <a href="#/register">Daftar</a></p>
            <div id="login-message" class="login-message" role="alert" aria-live="polite"></div>
          </div>
        </div>
      </div>
    `;
  }

  async afterRender() {
    this.form = document.getElementById('login-form');
    this.messageContainer = document.getElementById('login-message');
    this.submitButton = document.getElementById('submit-button');

    this.presenter = new LoginPagePresenter({
      onSuccess: () => {
        this.form.reset();
        this.redirectToHome();
      },
      onMessage: (message) => {
        this.showMessage(message);
      },
      onLoading: (isLoading) => {
        this.submitButton.disabled = isLoading;
        this.submitButton.textContent = isLoading ? 'Loading..' : 'Masuk';
      },
    });

    this.bindSubmit((credentials) => {
      this.presenter.submitLogin(credentials);
    });
  }

  bindSubmit(handler) {
    this.form.addEventListener('submit', (event) => {
      event.preventDefault();
      const email = this.form.email.value.trim();
      const password = this.form.password.value.trim();
      handler({ email, password });
    });
  }

  showMessage(message) {
    this.messageContainer.textContent = message;
  }

  redirectToHome() {
    window.location.hash = '#/';
  }
}

export default new LoginPage();
