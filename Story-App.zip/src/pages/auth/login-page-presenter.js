import Api from '../../data/api.js';

class LoginPagePresenter {
  constructor({ onSuccess, onMessage, onLoading }) {
    this.onSuccess = onSuccess;
    this.onMessage = onMessage;
    this.onLoading = onLoading;
  }

  async submitLogin({ email, password }) {
    this._setMessage('');
    this._setLoading(true);

    if (!email || !password) {
      this._setMessage('Isi Semua Kolom Dulu');
      this._setLoading(false);
      return;
    }

    try {
      const response = await Api.login({ email, password });
      if (!response.error) {
        localStorage.setItem('token', response.loginResult.token);
        localStorage.setItem('userName', response.loginResult.name);
        this._setMessage('Login Berhasil');
        setTimeout(() => {
          if (typeof this.onSuccess === 'function') {
            this.onSuccess();
          }
        }, 1000); // Delay before redirecting
      } else {
        this._setMessage(response.message || 'Login Gagal.');
      }
    } catch (error) {
      this._setMessage('Login Gagal. Coba Lagi Gais.');
    } finally {
      this._setLoading(false);
    }
  }

  _setMessage(message) {
    if (typeof this.onMessage === 'function') {
      this.onMessage(message);
    }
  }

  _setLoading(isLoading) {
    if (typeof this.onLoading === 'function') {
      this.onLoading(isLoading);
    }
  }
}

export default LoginPagePresenter;
