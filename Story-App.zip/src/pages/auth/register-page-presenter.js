import Api from '../../data/api.js';

class RegisterPagePresenter {
  constructor({ onSuccess, onMessage, onLoading }) {
    this.onSuccess = onSuccess;
    this.onMessage = onMessage;
    this.onLoading = onLoading;
  }

  async submitRegistration({ name, email, password }) {
    this._setMessage('');
    this._setLoading(true);

    if (!name || !email || !password) {
      this._setMessage('Tolong isi semua form');
      this._setLoading(false);
      return;
    }

    if (password.length < 8) {
      this._setMessage('Password harus lebih dari 8 karakter');
      this._setLoading(false);
      return;
    }

    try {
      const response = await Api.register({ name, email, password });

      if (!response.error) {
        this._setMessage('Mantap!! User berhasil dibuat');
        setTimeout(() => {
          if (typeof this.onSuccess === 'function') {
            this.onSuccess();
          }
        }, 10000);
      } else {
        this._setMessage(response.message || 'Registrasi Gagal ');
      }
    } catch (error) {
      this._setMessage('Registrasi Gagal, Coba Lagi! ');
    } finally {
      this._setLoading(false);
    }
  }

  _setMessage(message) {
    if (typeof this.onMessage === 'function') {
      this.onMessage(message);
    }
  }

  _setLoading(isLoading) {
    if (typeof this.onLoading === 'function') {
      this.onLoading(isLoading);
    }
  }
}

export default RegisterPagePresenter;
