import Api from '../../data/api.js';


class HomePagePresenter {
  constructor(view) {
    this.view = view;
  }

  async init() {
    const token = localStorage.getItem('token');
    if (!token) {
      window.location.hash = '#/login';
      return;
    }

    this.view.bindLogoutButton(this._onLogout.bind(this));
    this.view.bindAddStoryButton(this._onAddStory.bind(this));

    this.view.showLoading();
    await this._fetchAndRenderStories(token);
  }

  async _fetchAndRenderStories(token) {
    try {
      const response = await Api.getStories({ token });
      if (!response.error && response.listStory.length > 0) {
        localStorage.setItem('stories', JSON.stringify(response.listStory));
        this.view.showStories(response.listStory);
      } else {
        this.view.showError('Story Tidak DItemukan');
      }
    } catch (error) {
      console.error('Error fetching stories:', error);
      this.view.showError('Gagal Memuat Story');
    }
  }

  _onLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userName');
    window.location.hash = '#/login';
  }

  _onAddStory() {
    window.location.hash = '#/add-story';
  }
}

export default HomePagePresenter;
