import HomePagePresenter from './home-page-presenter.js';
import CONFIG from '../../utils/config.js';
import { urlBase64ToUint8Array } from '../../utils/utils.js';

const HomePage = {
  async render() {
    return `
      <div data-page="home">
        <header class="header">
          <h1><i class="fa-solid fa-video"></i> Story-App</h1>
          <div class="header-buttons">
            <button id="saved-stories-button" class="btn btn-primary" title="Saved-Story"><i class="fa-solid fa-bookmark"></i></button>
            <button id="push-btn" class="btn btn-primary" title="Subscribe"><i class="fa-solid fa-bell"></i></button>
            <button id="add-story-button" class="btn btn-primary" title="Buat-Story"><i class="fa-solid fa-plus"></i></button>
            <button id="logout-button" class="btn btn-primary" title="Logout"><i class="fa-solid fa-right-from-bracket"></i></button>
          </div>
        </header>
        <section>
          <div id="story-list" class="story-list">
            <p>Loading stories...</p>
          </div>
        </section>
        <div id="saved-modal" class="modal hidden">
          <div class="modal-content">
            <div class="saved-stories-title">
              <h2>Saved Stories</h2>
              <div class="modal-header button-group">
                <button id="clear-saved-button" class="btn btn-clear">Clear</button>
                <button id="close-saved-modal" class="btn btn-close"></button>
              </div>
            </div>
            <div id="saved-stories-container"></div>
          </div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    const presenter = new HomePagePresenter(this);
    await presenter.init();

    const modal = document.getElementById("saved-modal");
    const triggerBtn = document.getElementById("saved-stories-button");
    const closeBtn = document.getElementById("close-saved-modal");
    const clearBtn = document.getElementById("clear-saved-button");
    const savedContainer = document.getElementById("saved-stories-container");

    const renderSavedStories = async () => {
      const { getSavedStories, deleteStory } = await import('../../utils/indexeddb.js');
      let stories = await getSavedStories();
      if (!Array.isArray(stories)) stories = [];

      savedContainer.innerHTML = "";

      if (stories.length === 0) {
        savedContainer.innerHTML = "<p>Tidak ada story yang disimpan.</p>";
        return;
      }

      stories.forEach((story) => {
        const storyDiv = document.createElement("div");
        storyDiv.className = "story-card";
        storyDiv.innerHTML = `
          <div class="story-header" style="display:flex; justify-content:space-between; align-items:start;">
            <div>
              <h2>${story.name}</h2>
              <p class="teks">${story.description}</p>
            </div>
            <button class="delete-story-btn" data-id="${story.id}" style="border:none; background:transparent; font-weight:bold; font-size:18px; cursor:pointer;"></button>
          </div>
          <img src="${story.photoUrl}" alt="${story.id}" style="max-width: 430px; height: auto;" />
          <p class="teks">Dibuat: ${new Date(story.createdAt).toLocaleString()}</p>
          <p class="teks">Posisi: Lat (${story.lat || 'N/A'}), Lon (${story.lon || 'N/A'})</p>
        `;

        savedContainer.appendChild(storyDiv);

        const deleteBtn = storyDiv.querySelector('.delete-story-btn');
        deleteBtn.addEventListener('click', async () => {
          await deleteStory(story.id);
          renderSavedStories();
        });
      });
    };

    triggerBtn.addEventListener("click", async () => {
      await renderSavedStories();
      modal.classList.remove("hidden");
    });

    closeBtn.addEventListener("click", () => {
      modal.classList.add("hidden");
    });

    clearBtn.addEventListener("click", async () => {
      const { clearAllStories } = await import('../../utils/indexeddb.js');
      await clearAllStories();
      await renderSavedStories();
    });

    //``````` Push Notification Logic
    const pushButton = document.getElementById("push-btn");
    let isSubscribed = false;
    let swRegistration = null;

    if ('serviceWorker' in navigator && 'PushManager' in window) {
      navigator.serviceWorker.ready
        .then(reg => {
          swRegistration = reg;
          return reg.pushManager.getSubscription();
        })
        .then(subscription => {
          isSubscribed = !(subscription === null);
          updatePushButton();
        });

      pushButton.addEventListener("click", async () => {
        if (isSubscribed) {
          await unsubscribeUser();
        } else {
          await subscribeUser();
        }
      });
    }

    function updatePushButton() {
      if (isSubscribed) {
        pushButton.innerHTML = `<i class="fa-solid fa-bell-slash"></i>`;
        pushButton.title = 'Unsubscribe';
      } else {
        pushButton.innerHTML = `<i class="fa-solid fa-bell"></i>`;
        pushButton.title = 'Subscribe';
      }
    }

    async function subscribeUser() {
      const subscription = await swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(CONFIG.VAPID_KEY),
      });

      const token = localStorage.getItem("token");

      const p256dh = btoa(String.fromCharCode(...new Uint8Array(subscription.getKey('p256dh'))));
      const auth = btoa(String.fromCharCode(...new Uint8Array(subscription.getKey('auth'))));

      const payload = {
        endpoint: subscription.endpoint,
        keys: {
          p256dh,
          auth,
        },
      };

      await fetch(`${CONFIG.BASE_URL}/notifications/subscribe`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      isSubscribed = true;
      updatePushButton();
    }

    async function unsubscribeUser() {
      const subscription = await swRegistration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();

        const token = localStorage.getItem("token");
        await fetch(`${CONFIG.BASE_URL}/notifications/subscribe`, {
          method: "DELETE",
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ endpoint: subscription.endpoint }),
        });
      }

      isSubscribed = false;
      updatePushButton();
    }
  },

  bindAddStoryButton(handler) {
    const button = document.getElementById('add-story-button');
    if (button) button.addEventListener('click', handler);
  },

  bindLogoutButton(handler) {
    const button = document.getElementById('logout-button');
    if (button) button.addEventListener('click', handler);
  },

  showLoading() {
    const list = document.getElementById('story-list');
    if (list) list.innerHTML = '<p>Loading stories...</p>';
  },

  showError(message) {
    const list = document.getElementById('story-list');
    if (list) list.innerHTML = `<p>${message}</p>`;
  },

  async showStories(stories) {
    const container = document.getElementById('story-list');
    container.innerHTML = '';

    const { getSavedStories, saveStory, deleteStory } = await import('../../utils/indexeddb.js');

    if (!navigator.onLine) {
      const offlineStories = await getSavedStories();
      if (!offlineStories.length) {
        return container.innerHTML = "<p>Tidak ada data (offline).</p>";
      }
      stories = offlineStories;
    }

    const savedStories = await getSavedStories();
    const savedIds = savedStories.map(story => story.id);

    stories.forEach((story, index) => {
      const storyElement = document.createElement('div');
      storyElement.className = 'story-item';

      const imageTransitionName = `story-image-${story.id || index}`;
      const isSaved = savedIds.includes(story.id);
      const saveLabel = isSaved ? 'Unsave' : 'Save';

      storyElement.innerHTML = `
        <div class="story-card">
          <div class="story-header">
            <h2>${story.name}</h2>
            <p class="teks">${story.description}</p>
          </div>
          <img src="${story.photoUrl}" 
              alt="Photo : ${story.id}" 
              style="max-width: 100%; height: auto; cursor: pointer;" 
              viewTransitionName="${imageTransitionName}" />
          <p class="teks">Dibuat: ${new Date(story.createdAt).toLocaleString()}</p>
          <p class="teks">Posisi: Lat (${story.lat || 'N/A'}), Lon (${story.lon || 'N/A'})</p>
          <button class="save-btn" data-id="${story.id}">${saveLabel}</button>
        </div>
      `;

      const image = storyElement.querySelector('img');
      const saveBtn = storyElement.querySelector('.save-btn');

      image.addEventListener('click', () => {
        if (document.startViewTransition) {
          image.style.viewTransitionName = `story-image`;
          const transition = document.startViewTransition(() => {
            window.location.hash = `#/story-detail/${story.id}`;
          });
          transition.finished.then(() => {
            image.style.viewTransitionName = '';
          });
        } else {
          window.location.hash = `#/story-detail/${story.id}`;
        }
      });

      saveBtn.addEventListener('click', async () => {
        if (saveBtn.innerText === 'Save') {
          await saveStory(story);
          saveBtn.innerText = 'Unsave';
        } else {
          await deleteStory(story.id);
          saveBtn.innerText = 'Save';
        }
      });

      container.appendChild(storyElement);
    });
  },
};

export default HomePage;
