import Api from '../../data/api.js';

class AddStoryPagePresenter {
  constructor(view) {
    this.view = view;
    this.stream = null;
  }

  init() {
    this.view.bindFormSubmit(this.handleSubmit.bind(this));

    this.view.bindCameraEvents({
      onOpen: this.handleOpenCamera.bind(this),
      onClose: this.handleCloseCamera.bind(this),
      onSwitch: this.handleSwitchCamera.bind(this),
      onCapture: this.handleCapturePhoto.bind(this),
    });

    this.view.bindUploadEvent(() => {
      this.view.form.photo.click();
    });

    this.view.bindPhotoInputChange(this.handlePhotoInputChange.bind(this));
  }

  async handleOpenCamera() {
    this.view.openCameraModal();
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(device => device.kind === 'videoinput');
      this.videoDevices = videoDevices;
      this.view.cameraSelect.innerHTML = videoDevices.map((device, idx) =>
        `<option value="${device.deviceId}">${device.label || `Kamera ${idx + 1}`}</option>`
      ).join('');
      await this.handleSwitchCamera(videoDevices[0]?.deviceId);
    } catch (error) {
      this.view.showMessage('Gagal Menggunakan Kamera, Tolong Beri Izin Untuk Akses Kamera.');
    }
  }

  async handleSwitchCamera(deviceId) {
    try {
      if (this.stream) {
        this.stream.getTracks().forEach(track => track.stop());
      }
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: deviceId ? { exact: deviceId } : undefined, facingMode: deviceId ? undefined : 'environment' }
      });
      this.view.cameraPreview.srcObject = this.stream;
      await this.view.cameraPreview.play();
    } catch (error) {
      this.view.showMessage('Gagal Mengganti Kamera.');
    }
  }

  handleCloseCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    this.view.cameraPreview.srcObject = null;
    this.view.closeCameraModal();
  }

  handleCapturePhoto() {
    if (!this.stream) return;
    const video = this.view.cameraPreview;
    const canvas = this.view.canvasElement;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    canvas.toBlob((blob) => {
      const file = new File([blob], "camera-photo.jpg", { type: "image/jpeg" });
      this.view.setPhotoFile(file);
      this.view.showPreviewImage(blob);
      this.handleCloseCamera();
    }, 'image/jpeg');
  }

  handlePhotoInputChange() {
    const input = this.view.form.photo;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = e => {
        this.view.showPreviewImage(e.target.result);
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  async handleSubmit({ description, photoInput, lat, lon }) {
    this.view.showMessage('');
    this.view.setSubmitLoading(true);

    if (!description.trim()) {
      this.view.showMessage('Wajib Masukan Deskripsi');
      this.view.setSubmitLoading(false);
      return;
    }
    if (!photoInput.files || photoInput.files.length === 0) {
      this.view.showMessage('Wajib Masukan Photo');
      this.view.setSubmitLoading(false);
      return;
    }
    const photo = photoInput.files[0];
    if (photo.size > 1024 * 1024) {
      this.view.showMessage('Ukuran Photo Harus Kurang Dari 1 MB (1024 kb)');
      this.view.setSubmitLoading(false);
      return;
    }
    let latNum = null, lonNum = null;
    if (lat) {
      latNum = parseFloat(lat);
      if (isNaN(latNum)) {
        this.view.showMessage('Latitude Harus Berupa Angka Valid');
        this.view.setSubmitLoading(false);
        return;
      }
    }
    if (lon) {
      lonNum = parseFloat(lon);
      if (isNaN(lonNum)) {
        this.view.showMessage('Longitude Harus Berupa Angka Valid');
        this.view.setSubmitLoading(false);
        return;
      }
    }
    const token = localStorage.getItem('token');
    if (!token) {
      this.view.showMessage('Kamu Harus Login Terlebih Dahulu');
      this.view.setSubmitLoading(false);
      return;
    }

    try {
      const response = await Api.addStory({
        token,
        description,
        photo,
        lat: latNum,
        lon: lonNum,
      });
      if (!response.error) {
        this.view.showMessage('Berhasil Menambahkan Story');
        this.view.resetForm();
        setTimeout(() => this.view.redirectToHome(), 1000);
      } else {
        this.view.showMessage(response.message || 'Gagal Menambahkan Story');
      }
    } catch (error) {
      this.view.showMessage('Gagal Menambahkan Story, Silakan Coba Lagi');
    } finally {
      this.view.setSubmitLoading(false);
    }
  }
}

export default AddStoryPagePresenter;
