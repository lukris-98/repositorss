import AddStoryPagePresenter from './add-story-page-presenter.js';
import Map from '../../utils/map';

const AddStoryPage = {
  async render() {
    return `
      <div data-page="add-story">
      <div class="container mx-auto max-w-4xl p-4">
        <header class="header mb-8 bg-white rounded-lg shadow-sm p-6 flex justify-between items-center">
          <h1 class="text-2xl font-bold text-gray-800">Add New Story</h1>
          <a href="#/" class="kembali">
            KEMBALI
          </a>
        </header>

        <div class="form-container bg-white rounded-lg shadow-sm p-6 space-y-6">
          <div class="map-section">
            <label class="block text-sm font-medium text-gray-700 mb-2">Location</label>
            <div id="map" class="w-full h-[300px] rounded-lg border border-gray-200 mb-4"></div>
            
            <div class="coordinates-container grid grid-cols-2 gap-4">
              <div>
                <label for="latitude" class="block text-sm font-medium text-gray-700 mb-1">Latitude</label>
                <input 
                  type="text" 
                  id="latitude" 
                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                  placeholder="e.g. -6.200000" 
                />
              </div>
              <div>
                <label for="longitude" class="block text-sm font-medium text-gray-700 mb-1">Longitude</label>
                <input 
                  type="text" 
                  id="longitude" 
                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-400 focus:border-transparent"
                  placeholder="e.g. 106.816666" 
                />
              </div>
            </div>
          </div>

          <div class="description-section">
            <label for="description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <textarea 
              id="description" 
              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-400 focus:border-transparent min-h-[120px]"
              placeholder="Write your story..."
            ></textarea>
          </div>

          <div class="photo-section">
            <label class="block text-sm font-medium text-gray-700 mb-2">Photo</label>
            <input type="file" id="image" accept="image/*" style="display: none;" />
            <div class="photo-input-container grid grid-cols-2 gap-4">
              <button type="button" class="camera-button bg-gray-800 hover:bg-gray-700 transition-colors" id="camera-button">
                <i class="fas fa-camera mr-2"></i>
                Take Photo
              </button>
              <button type="button" class="camera-button bg-gray-800 hover:bg-gray-700 transition-colors" id="upload-button">
                <i class="fas fa-upload mr-2"></i>
                Upload Image
              </button>
            </div>
            <div id="preview-container" class="mt-4 hidden">
              <img id="preview-image" class="max-w-full h-auto rounded-lg" />
            </div>
          </div>

          <button 
            id="submit" 
            class="w-full bg-gray-800 hover:bg-gray-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
          >
            Submit Story
          </button>
        </div>

        <div class="camera-modal fixed inset-0 bg-black bg-opacity-75 hidden" id="camera-modal">
          <div class="camera-modal-content bg-white rounded-lg max-w-2xl mx-auto mt-20 overflow-hidden">
            <div class="camera-header flex justify-between items-center p-4 border-b border-gray-200">
              <h2 class="text-xl font-semibold text-gray-800">Take Photo</h2>
              <button class="close-camera text-gray-500 hover:text-gray-700" id="close-camera">&times;</button>
            </div>
            <div class="camera-body p-4">
              <video id="camera-preview" class="w-full rounded-lg bg-gray-100" autoplay playsinline></video>
              <div class="camera-controls flex items-center gap-4 mt-4">
                <select id="camera-select" class="flex-1 px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="">Loading cameras...</option>
                </select>
                <button id="capture-button" class="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                  <i class="fas fa-camera mr-2"></i>
                  Capture
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    `;
  },

  async afterRender() {
    // Inisialisasi elemen
    this.form = {
      description: document.getElementById('description'),
      photo: document.getElementById('image'),
      lat: document.getElementById('latitude'),
      lon: document.getElementById('longitude'),
      submit: document.getElementById('submit'),
    };
    this.messageContainer = this._getOrCreateMessageContainer();
    this.previewImage = document.getElementById('preview-image');
    this.previewContainer = document.getElementById('preview-container');
    this.cameraModal = document.getElementById('camera-modal');
    this.cameraButton = document.getElementById('camera-button');
    this.uploadButton = document.getElementById('upload-button');
    this.closeButton = document.getElementById('close-camera');
    this.cameraPreview = document.getElementById('camera-preview');
    this.cameraSelect = document.getElementById('camera-select');
    this.captureButton = document.getElementById('capture-button');
    this.canvasElement = document.createElement('canvas'); // capture

    // Inisialisasi Map
    await this._initMap();

    // Inisialisasi Presenter
    this.presenter = new AddStoryPagePresenter(this);
    this.presenter.init();
  },

  // Interface untuk Presenter
  bindFormSubmit(handler) {
    this.form.submit.addEventListener('click', (e) => {
      e.preventDefault();
      handler({
        description: this.form.description.value,
        photoInput: this.form.photo,
        lat: this.form.lat.value,
        lon: this.form.lon.value,
      });
    });
  },

  bindCameraEvents({ onOpen, onClose, onSwitch, onCapture }) {
    this.cameraButton.addEventListener('click', onOpen);
    this.closeButton.addEventListener('click', onClose);
    this.cameraSelect.addEventListener('change', (e) => onSwitch(e.target.value));
    this.captureButton.addEventListener('click', onCapture);
  },

  bindUploadEvent(handler) {
    this.uploadButton.addEventListener('click', handler);
  },

  bindPhotoInputChange(handler) {
    this.form.photo.addEventListener('change', handler);
  },

  showMessage(message) {
    this.messageContainer.textContent = message;
    this.messageContainer.style.display = message ? 'block' : 'none';
  },

  showPreviewImage(blobOrUrl) {
    if (typeof blobOrUrl === 'string') {
      this.previewImage.src = blobOrUrl;
    } else {
      this.previewImage.src = URL.createObjectURL(blobOrUrl);
    }
    this.previewContainer.classList.remove('hidden');
  },

  hidePreviewImage() {
    this.previewContainer.classList.add('hidden');
    this.previewImage.src = '';
  },

  openCameraModal() {
    this.cameraModal.classList.remove('hidden');
  },

  closeCameraModal() {
    this.cameraModal.classList.add('hidden');
  },

  setPhotoFile(file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    this.form.photo.files = dt.files;
  },

  resetForm() {
    this.form.description.value = '';
    this.form.photo.value = '';
    this.form.lat.value = '';
    this.form.lon.value = '';
    this.hidePreviewImage();
  },

  redirectToHome() {
    window.location.hash = '#/';
  },

  setSubmitLoading(isLoading) {
    this.form.submit.disabled = isLoading;
    this.form.submit.textContent = isLoading ? 'Submitting...' : 'Submit Story';
  },

  async _initMap() {
    const fetchStreetName = async (lat, lng) => {
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`
        );
        const data = await response.json();
        return data.address?.road || 'Unnamed Road';
      } catch (error) {
        return 'Street name not found';
      }
    };

    try {
      const map = await Map.build('#map', { zoom: 13, locate: true });
      const center = map.getCenter();
      const marker = map.addMarker([center.latitude, center.longitude], { draggable: true });

      marker.on('dragend', async (event) => {
        const position = event.target.getLatLng();
        this.form.lat.value = position.lat;
        this.form.lon.value = position.lng;
        const streetName = await fetchStreetName(position.lat, position.lng);
        marker.bindPopup(`<strong>${streetName}</strong>`).openPopup();
      });

      map.addMapEventListener('click', async (event) => {
        marker.setLatLng(event.latlng);
        this.form.lat.value = event.latlng.lat;
        this.form.lon.value = event.latlng.lng;
        const streetName = await fetchStreetName(event.latlng.lat, event.latlng.lng);
        marker.bindPopup(`<strong>${streetName}</strong>`).openPopup();
      });

      this.form.lat.value = center.latitude;
      this.form.lon.value = center.longitude;
      const initialStreetName = await fetchStreetName(center.latitude, center.longitude);
      marker.bindPopup(`<strong>${initialStreetName}</strong>`).openPopup();
    } catch (error) {
      this.showMessage('Failed to initialize map. Please try again.');
    }
  },

  _getOrCreateMessageContainer() {
    let el = document.getElementById('add-story-message');
    if (!el) {
      el = document.createElement('div');
      el.id = 'add-story-message';
      el.className = 'text-red-600 mt-2';
      this.form.submit.parentNode.insertBefore(el, this.form.submit);
    }
    return el;
  },
};

export default AddStoryPage;
